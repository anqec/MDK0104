using System;
using System.Threading;

string[] methods = { "Без синхронизации", "lock", "Monitor", "Mutex" };

foreach (string method in methods)
{
    BankAccount account = new BankAccount(method);

    Thread t1 = new Thread(() => AddManyTimes(account, 100));
    Thread t2 = new Thread(() => AddManyTimes(account, 200));
    Thread t3 = new Thread(() => AddManyTimes(account, 300));

    t1.Start();
    t2.Start();
    t3.Start();

    t1.Join();
    t2.Join();
    t3.Join();

    Console.WriteLine($"{method}: {account.Balance} (ожидается 60000)");
}

static void AddManyTimes(BankAccount account, int amount)
{
    for (int i = 0; i < 100; i++)
    {
        account.Deposit(amount);
    }
}
