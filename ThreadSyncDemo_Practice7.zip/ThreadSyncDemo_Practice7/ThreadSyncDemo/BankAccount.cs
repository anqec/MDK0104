using System;
using System.Threading;

class BankAccount
{
    private int balance = 0;
    private readonly object locker = new object();
    private readonly Mutex mutex = new Mutex();
    private readonly string method;

    public int Balance => balance;

    public BankAccount(string method)
    {
        this.method = method;
    }

    public void Deposit(int amount)
    {
        if (method == "lock")
        {
            lock (locker)
            {
                AddMoney(amount);
            }
        }
        else if (method == "Monitor")
        {
            Monitor.Enter(locker);
            try
            {
                AddMoney(amount);
            }
            finally
            {
                Monitor.Exit(locker);
            }
        }
        else if (method == "Mutex")
        {
            mutex.WaitOne();
            try
            {
                AddMoney(amount);
            }
            finally
            {
                mutex.ReleaseMutex();
            }
        }
        else
        {
            AddMoney(amount); // Без синхронизации
        }
    }

    private void AddMoney(int amount)
    {
        int oldBalance = balance;
        Thread.Sleep(1); // Чтобы было видно ошибку без синхронизации
        balance = oldBalance + amount;
    }
}
